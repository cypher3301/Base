create
    definer = starscream@localhost procedure getemployes(OUT cnt int)
begin
    select * from employs where id=id;
end;

