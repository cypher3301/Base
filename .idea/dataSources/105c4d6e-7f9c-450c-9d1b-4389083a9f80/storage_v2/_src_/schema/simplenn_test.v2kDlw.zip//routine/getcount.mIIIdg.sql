create
    definer = starscream@localhost procedure getcount(OUT cnt int)
begin
    select count(*) into cnt from employs;
#     select count(*) into cnt from employ;
#     select count(*) into cnt from test;
    select count(*) into cnt from testphones;
end;

