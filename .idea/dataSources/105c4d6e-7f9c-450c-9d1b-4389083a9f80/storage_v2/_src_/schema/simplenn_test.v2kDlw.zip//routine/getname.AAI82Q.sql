create
    definer = starscream@localhost procedure getname(IN p_phone int, OUT p_name varchar(30))
BEGIN
    SELECT name INTO p_name FROM testphones WHERE phone=p_phone;
end;

