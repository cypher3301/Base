create
    definer = starscream@localhost procedure employscount(OUT cnt int)
begin
    select count(*) into cnt from employs;
end;

